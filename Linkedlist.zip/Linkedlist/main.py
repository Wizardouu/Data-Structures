class newNode:
    next=None
    previous=None
    data=0
    def __init__(self,value):
        self.data=value
class Node:
    next=newNode(0)
    previous=newNode(0)
    data=0
    def __init__(self,value):
        self.data=value
class LinkedList:
    head=Node(None)
    tail=Node(None)
    size=0
    def __init__(self):
        self.head.previous=None
        self.head.next=None
        self.tail.previous = None
        self.tail.next = None
    def isempty(self):
        return self.size==0
    def insert(self,value):
        self.size=self.size+1
        node=Node(value)
        if(self.size==1):
            self.head=node
            self.tail=node
        else:
            self.tail.next=node
            node.previous=self.tail
            self.tail=node
    def addhead(self,value):
        self.size = self.size + 1
        node = Node(value)
        if (self.size == 1):
            self.head = node
            self.tail = node
        else:
            self.head.previous = node
            node.next = self.head
            self.head = node
    def search(self,value):
        node=Node(-1)
        flag=0
        node=self.head
        while(node != None):
            if (node.data == value):
                flag=1
                return 1
            node=node.next
        if flag==0:
            print("Not Found !")
        return 0



    def remove(self,value):
        flag=self.search(value)
        if(not flag):
            return
        node=Node(-1)
        node=self.head
        while(node != None):
            if(node.data==value):
                if(node == self.head):
                    self.head=node.next
                    self.head.previous=None
                elif(node == self.tail):
                    self.tail=node
                    self.tail.next=None
                else:
                    before=Node(-1)
                    after=Node(-1)
                    before = node.previous
                    after = node.next
                    before.next=after
                    after.previous=before
            node=node.next
        self.size=self.size-1
    def display(self):
        node = self.head
        i=0
        print("The Linked List :",end=' ')
        while (node != None):
            i+=1
            if(i==self.size):
                print(node.data)
                return
            print(node.data,end=' -> ')
            node=node.next
    def reverse(self):
        node = self.tail
        i=0
        print("The Reversed Linked List :",end=' ')
        while (node != None):
            i+=1
            if(i==self.size):
                print(node.data)
                return
            print(node.data,end=' -> ')
            node=node.previous
    def getmin(self):
        node = Node(-1)
        min = self.head.data
        node = self.head
        while (node.next != None):
            if (node.data < min):
                min = node.data
            node = node.next
        return min
    def sort(self):
        arr=[-1]*self.size
        for i in range (self.size):
            value=self.getmin()
            self.remove(value)
            arr[i]=value
        for i in range(len(arr)):
            self.insert(arr[i])



list=LinkedList()
list.insert(190)
list.insert(189)
list.insert(700)
list.insert(150)
list.insert(22)
list.display()
print(list.head.next.data)
list.sort()
list.display()





