class newNode:
    left = None
    right = None
    data = 0

    def __init__(self, value):
        self.data = value


class Node:
    left = newNode(None)
    right = newNode(None)

    data = 0

    def __init__(self, value):
        self.data = value

def insert(root:Node, value):
    if (root.right==None and root.left==None):
        return Node(value)
    elif (root.data > value):
        root.left=insert(root.left, value)
    else:
        root.right=insert(root.right, value)
    return root
def inorder(root:Node):
    if (not(root.right==None and root.left==None)):
        inorder(root.left)
        print(root.data,end='  ')
        inorder(root.right)
def preorder(root:Node):
    if (not(root.right==None and root.left==None)):
        print(root.data,end='  ')
        inorder(root.left)
        inorder(root.right)
def postorder(root:Node):
    if (not(root.right==None and root.left==None)):
        inorder(root.left)
        inorder(root.right)
        print(root.data,end='  ')
def search(root:Node,value):
    if(root.data==value):
        print("found")
        return 1
    elif(root.right==None and root.left==None):
        print("not found")
        return 0
    elif(root.data>value):
        search(root.left,value)
    else:
        search(root.right,value)
def getcurrent(root:Node,value):
    if(root.left!=None and root.right!=None):
       if(root.data==value):
          return root
       elif(root.data>value):
          return getcurrent(root.left,value)
       else:
          return getcurrent(root.right,value)
def getparent(root:Node,value):
    if(root.left!=None and root.right!=None):
       if(root.left.data==value or root.right.data==value):
          return root
       elif(root.data>value):
          return getparent(root.left,value)
       else:
          return getparent(root.right,value)
def getmax(root:Node):
    if (root.right.right==None):
        return root
    else: return getmax(root.right)
def getmin(root:Node):
    if (root.left.left==None):
        return root
    else: return getmin(root.left)
def delete(root:Node,value):
    if (root.right==None and root.left==None):
        return root
    elif (root.data > value):
        root.left=delete(root.left, value)
    elif(root.data < value):
        root.right=delete(root.right, value)
    else:

        if(root.left.left !=None and root.right.right != None):
            temp=getmin(root.right)
            root.data=temp.data
            print(temp.data)
            root.right=delete(root.right,temp.data)
        else:
            temp=root
            if(root.left.left==None):
                root=root.right
            elif(root.right.right==None):
                root=root.left
            del(temp)
    return root
def successor(root,value):
    node=getcurrent(root,value)
    if(node.data==None):
        return None
    else:
        if(node.right.right != None):
          print("dfdsf")
          temp=getmin(node.right)
        else:
          temp=getparent(root,value)
        return temp
def decessor(root,value):
    node=getcurrent(root,value)
    if(node.data==None):
        return None
    else:
        if(node.left.left != None):
          print("dfdsf")
          temp=getmax(node.left)
        else:
          temp=getparent(root,value)
        return temp
def count(root):
    if(root.right==None and root.left==None):
        return 0
    else:
        return 1+count(root.left)+count(root.right)
def height(root):
    if(root.right==None and root.left==None):
        return 0
    else:
        return 1+max(height(root.left),height(root.right))





root=Node(5)
insert(root,10)
insert(root,2)
insert(root,12)
insert(root,24)
insert(root,36)
insert(root,1)
#search(root,2)
node=getcurrent(root,12)
node2=getparent(root,2)
#print(node2.data)
#print(getmin(root).data)
#root=delete(root,1)
#print(decessor(root,12).data)
print(height(root))








