class Heap:
    def __init__(self,n):
        self.heaparray=[0]*n
        self.pointer=0

    def swap(self, x1, x2):
        temp = self.heaparray[x1]
        self.heaparray[x1] = self.heaparray[x2]
        self.heaparray[x2] = temp

    def siftup(self,i):
        parent = (i - 1) // 2
        while ((i != 0) and self.heaparray[i]>self.heaparray[parent]):
            self.swap(i,parent)
            i = parent
            parent = (i - 1) // 2

    def buildheap(self,arr):
        for i in range(len(arr)):
            self.insertheap(arr[i])

    def insertheap(self, x):
        self.heaparray[self.pointer] = x
        self.siftup(self.pointer)
        self.pointer += 1
    def printheap(self):
        for i in range(self.pointer):
            print(self.heaparray[i],end='  ')
        print("")

    def pop(self):
      x = self.heaparray[0]
      self.pointer=self.pointer-1
      self.heaparray[0] = self.heaparray[self.pointer]
      self.siftdown(0)
      return x
    def siftdown(self,i):
        large = i
        l = 2 * i + 1
        r = 2 * i + 2
        if(l<self.pointer):
           arr1 = str(self.heaparray[l]).split('$')
        else:
            arr1=[0,0,0]
        arr2 = str(self.heaparray[large]).split('$')
        if (r < self.pointer):
            arr3 = str(self.heaparray[r]).split('$')
        else:
            arr3=[0,0,0]
        if (l < self.pointer and self.heaparray[l]>self.heaparray[large]):
            large=l
        if (r < self.pointer and self.heaparray[r] > self.heaparray[large]):
            large=r
        if (large != i):
            self.swap(i,large)
            self.siftdown(large)

    def heapsort(self):
        for i in range(self.pointer//2-1,0,-1):
            self.siftdown(i)
        w=self.pointer- 1
        for i in range(w, 0, -1):
            self.swap(0,i)
            self.pointer-=1
            self.siftdown(0)
        self.pointer=w+1
    def isempty(self):
        if(self.pointer==0):
            return 1
        else:
            return 0
heap=Heap(10)
heap.insertheap(5)
heap.insertheap(15)
heap.insertheap(17)
heap.insertheap(2)
heap.insertheap(58)
heap.insertheap(1)
print(heap.pop())

