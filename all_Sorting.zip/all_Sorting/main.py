import heapq
import random

def bubblesort(arr):
    n = len(arr)
    for i in range(1,n):
        for j in range(n-i):
            if(arr[j]>arr[j+1]):
                arr[j],arr[j+1] = arr[j+1] , arr[j]
    return arr
def insertionsort(arr):
    n = len(arr)
    for i in range(1,n):
        x = i
        while(x>0 and arr[x-1] > arr[x]):
            arr[x],arr[x-1] = arr[x-1],arr[x]
            x = x-1
    return arr
def selectionsort(arr):
    n = len(arr)
    for i in range(n):
        min= i
        for j in range(i,n):
            if(arr[j] < arr[min]):
                min = j
        arr[i],arr[min]=arr[min],arr[i]
    return arr

def mergesort(l,h,arr):
    mid = (l+h)//2
    if(l == h):
        return [arr[l]]
    else:
        return mergearrays(mergesort(l,mid,arr),mergesort(mid+1,h,arr))
def mergearrays(arr1 , arr2):
    m = len(arr1)
    n = len(arr2)
    c = [0] * (m+n)
    i = j = k = 0
    while(i<m and j < n):
        if(arr1[i] < arr2[j]):
            c[k] = arr1[i]
            i=i+1
            k = k+1
        else:
            c[k] = arr2[j]
            j = j + 1
            k = k + 1
    while(i < m):
        c[k] = arr1[i]
        i = i + 1
        k = k + 1
    while(j < n):
        c[k] = arr2[j]
        j = j + 1
        k = k + 1
    return c
def heapsort(arr):
    heapq.heapify(arr)
    n = len(arr)
    arr2 = []
    for i in range(n):
        arr2.append(heapq.heappop(arr))
    return arr2
def quicksort(arr,l,h):
    if(not(l>h)):
        if(l==h):
            return arr[l]
        else:
            pivot = arr[l]
            j = l+1
            for i in range(l+1,h+1):
                if(arr[i] < pivot):
                    arr[j] , arr[i] = arr [i] , arr[j]
                    j = j + 1
            j = j - 1
            arr[j], arr[l] = arr[l], arr[j]
            quicksort(arr,l,j-1)
            quicksort(arr,j+1,h)

test_cases = [random.sample(range(1, 101), 10) for _ in range(10)]

# Check sorting algorithms on test cases
for i, test in enumerate(test_cases, 1):
    print(f"Test Case {i}: {test}")
    print("Bubble Sort:", bubblesort(test.copy()))
    print("Insertion Sort:", insertionsort(test.copy()))
    print("Selection Sort:", selectionsort(test.copy()))
    print("Merge Sort:", mergesort(0,len(test)-1,test.copy()))
    print("Heap Sort:", heapsort(test.copy()))
    quick_sorted = test.copy()
    quicksort(quick_sorted, 0, len(quick_sorted) - 1)
    print("Quick Sort:", quick_sorted)
    print("-" * 40)